<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @package    Wp_Emp_Login
 * @subpackage Wp_Emp_Login/public/partials
 */

?>

<div id="wpempRegisterSection" class="container-fluid">
    <div class="row">
        <div class="col-xs-8 col-md-10"> 
            <?php
            $wpemp_form_settings = get_option('wpemp_form_settings');
            $form_heading = empty($wpemp_form_settings['wpemp_signup_heading']) ? 'Register' : $wpemp_form_settings['wpemp_signup_heading'];

            // check if the user already login
            if (!is_user_logged_in()) :

                ?>

                <form name="wpempRegisterForm" id="wpempRegisterForm" method="post">
                    <h3><?php _e($form_heading, $this->plugin_name); ?></h3>

                    <div id="wpemp-reg-loader-info" class="wpemp-loader" style="display:none;">
                        <img src="<?php echo plugins_url('images/ajax-loader.gif', dirname(__FILE__)); ?>"/>
                        <span><?php _e('Please wait ...', $this->plugin_name); ?></span>
                    </div>
                    <div id="wpemp-register-alert" class="alert alert-danger" role="alert" style="display:none;"></div>
                    <div id="wpemp-mail-alert" class="alert alert-danger" role="alert" style="display:none;"></div>
                    <?php if ($token_verification): ?>
                        <div class="alert alert-info" role="alert"><?php _e('Your account has been activated, you can login now.', $this->plugin_name); ?></div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="firstname"><?php _e('First name', $this->plugin_name); ?></label>
                        <sup class="wpemp-required-asterisk">*</sup>
                        <input type="text" class="form-control" name="wpemp_fname" id="wpemp_fname" placeholder="First name">
                    </div>
                    <div class="form-group">
                        <label for="lastname"><?php _e('Last name', $this->plugin_name); ?></label>
                        <input type="text" class="form-control" name="wpemp_lname" id="wpemp_lname" placeholder="Last name">
                    </div>
                    <div class="form-group">
                        <label for="username"><?php _e('Username', $this->plugin_name); ?></label>
                        <sup class="wpemp-required-asterisk">*</sup>
                        <input type="text" class="form-control" name="wpemp_username" id="wpemp_username" placeholder="Username">
                    </div>
                    <div class="form-group">
                        <label for="email"><?php _e('Email', $this->plugin_name); ?></label>
                        <sup class="wpemp-required-asterisk">*</sup>
                        <input type="text" class="form-control" name="wpemp_email" id="wpemp_email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <label for="password"><?php _e('Password', $this->plugin_name); ?></label>
                        <sup class="wpemp-required-asterisk">*</sup>
                        <input type="password" class="form-control" name="wpemp_password" id="wpemp_password" placeholder="Password" >
                    </div>
                    <div class="form-group">
                        <label for="confrim password"><?php _e('Confirm Password', $this->plugin_name); ?></label>
                        <sup class="wpemp-required-asterisk">*</sup>
                        <input type="password" class="form-control" name="wpemp_password2" id="wpemp_password2" placeholder="Confirm Password" >
                    </div>

                    <?php if ($wpemp_form_settings['wpemp_enable_captcha'] == '1') { ?>
                        <div class="form-group">
                            <label class="control-label" id="captchaOperation"></label>

                            <input type="text" placeholder="Captcha answer" class="form-control" name="wpemp_captcha" />

                        </div>
                    <?php } ?>

                    <input type="hidden" name="wpemp_current_url" id="wpemp_current_url" value="<?php echo get_permalink(); ?>" />
                    <input type="hidden" name="redirection_url" id="redirection_url" value="<?php echo get_permalink(); ?>" />

                    <?php
                    // this prevent automated script for unwanted spam
                    if (function_exists('wp_nonce_field'))
                        wp_nonce_field('wpemp_register_action', 'wpemp_register_nonce');

                    ?>
                    <button type="submit" class="btn btn-primary">
                        <?php
                        $submit_button_text = empty($wpemp_form_settings['wpemp_signup_button_text']) ? 'Register' : $wpemp_form_settings['wpemp_signup_button_text'];
                        _e($submit_button_text, $this->plugin_name);

                        ?></button>
                </form>
                <?php
            else:
                $current_user = wp_get_current_user();
                $logout_redirect = (empty($wpemp_form_settings['wpemp_logout_redirect']) || $wpemp_form_settings['wpemp_logout_redirect'] == '-1') ? '' : $wpemp_form_settings['wpemp_logout_redirect'];

                echo 'Logged in as <strong>' . ucfirst($current_user->user_login) . '</strong>. <a href="' . wp_logout_url(get_permalink($logout_redirect)) . '">Log out ? </a>';
            endif;

            ?>
        </div>
    </div>
</div>
