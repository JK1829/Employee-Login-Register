
<div style="width: 23%;float:left;padding: 15px;border: 1px solid #777;background: #fff;">
        <h1 style="text-align: center;font-size: 38px;padding-bottom: 30px;"> Shortcodes</h1>
        <p style=""><strong style="font-size: 18px;">Registration Form:</strong>
            <code style="font-size: 16px;">[wpemp_register_form]</code></p>
        <p> <strong style="font-size: 20px;">Login Form:</strong>
            <code style="font-size: 17px;">[wpemp_login_form]</code></p>
        <p> <strong style="font-size: 20px;">Profile Page:</strong>
            <code style="font-size: 17px;">[wpemp_user_profile]</code></p>
    </div>